# React Pokedex

A Pen created on CodePen.io. Original URL: [https://codepen.io/RedPillPhil/pen/gOdvKzG](https://codepen.io/RedPillPhil/pen/gOdvKzG).

Made a Pokedex in React!